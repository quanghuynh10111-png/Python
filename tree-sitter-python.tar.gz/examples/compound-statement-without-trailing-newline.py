class Foo:
  def bar():
    print "hi"