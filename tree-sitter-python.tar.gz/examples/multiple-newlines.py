def hi():



    print "hi"


def bye():
    print "bye"
















